<?php

/*

Demande de confirmation pour supprimez sa candidature, apres avoir cliquez sur Retirez ma candidature

Envoye ici par alliance.php - Ligne 12

Gestion des candidature multiple par Max485

*/

$page = " Voulez vous vraiment retirer votre candidature ?<br><br>
<form method='post' action='index.php?mod=alliances/enleve2'>   
<input type='submit' name='confirmez' value ='OUI'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type='submit' name='confirmez' value ='NON'></form>";
 


?>