<?php

// Si la constante n'est pas defini on bloque l'execution du fichier
if(!defined('PHPSIMUL_PAGES') || @PHPSIMUL_PAGES != 'PHPSIMULLL') 
{
die('Erreur 404 - Le fichier n\'a pas �t� trouv�');
}

/* PHPsimul : Cr�ez votre jeu de simulation en PHP
Copyright (�) - 2007 - CAPARROS S�bastien (Camaris)

Codeur officiel: Camaris & Max485
http://forum.epic-arena.fr

*/
/*

Le Mod Officier permet d'echanger des points obtenu par allopass par des actions diverses

Certaines action offres des choses, d'autre permettent de faire une action pendant un certains temps
(Chacune coute de "l'antimatiere" qui est aussi definissiable depuis l'administration

Tous est configurable dans l'administration dans la partie configuration allopass

*/


// Offre une quantit� de ressources (x ressources)






// Augmente la production (Pendant x temps et de z ressources)






// Termine immediatement le batiment en construction





// Ajoute un vaisseaux de votre choix dans la liste (liste vaisseaux achetable)






// Protection des vaisseaux amelior� (g% de protection en plus)





// Aumentation de la puissance des defences (d% de puissance en plus)




// Augmentation de la vitesse de construction (m% de baisse de temps)










// Pack d�fence construit des d�fenses d�fini dans ladmin - Id�e de Tereur







// Pack vaisseaux construit des vaisseaux d�fini dans ladmin - Id�e de Tereur










// Pack EcoBric (Contient plusieurs actions) - Id�e de Tereur


?>