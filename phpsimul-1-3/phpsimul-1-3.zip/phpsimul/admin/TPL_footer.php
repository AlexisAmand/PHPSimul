<?php

// Si la constante n'est pas defini on bloque l'execution du fichier
if(!defined('PHPSIMUL_PAGES') || @PHPSIMUL_PAGES != 'PHPSIMULLL') 
{
die('Erreur 404 - Le fichier n\'a pas �t� trouv�');
}

?>

</td></tr></table>

</div>
				</strong>
			</div>
		</td><tr>
	</table>
	<div class="copyrightZone">
		<strong>&copy; 2007-2008 Stevenson's mods v1.1 - Tout droits r�serv�s</strong>

	</div>
</div>
</body>
</html>