<?php

/*

Permet d'envoyer sur le fichier error404.php qui genere une erreur de detination, permet de faire croire a l'utilisteur 
que le repertoire n'existe pas

*/

include("../../systeme/error404.php");

?>