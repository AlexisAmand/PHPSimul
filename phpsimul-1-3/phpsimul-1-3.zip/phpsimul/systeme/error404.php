<?php

/*

Page app�l�e lorsqu'un quelqu'un tente d'acceder a un repertoire pour faire croire qu'il n'existe pas

Pour faire plus realiste, remplac� ce qui se trouve apres la balise ?> par le message d'erreur que vous 
affiche votre site quand y'en a vraiment une

Pour recuperer le code exact de votre site, faite clique droit, puis afficher la sources, ou trouv�e un truc
qui parle de code source

*/

?>


<html>
<i>404 File Not Found</i>
</html>
