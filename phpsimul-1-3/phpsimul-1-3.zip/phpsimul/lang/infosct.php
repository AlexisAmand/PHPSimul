<?php

//CE FICHIER DE LANGUE CONTIENT LA LANGE DE LA DESCRIPTION DES BATIMENTS, RECHERCHES, CHANTIER ET DEFENSES (d�tails des couts et de la production)

// Si la constante n'est pas defini on bloque l'execution du fichier
if(!defined('PHPSIMUL_PAGES') || @PHPSIMUL_PAGES != 'PHPSIMULLL') 
{
	die('Erreur 404 - Le fichier n\'a pas �t� trouv�');
}

/* 

PHPsimul : Cr�ez votre jeu de simulation en PHP
Copyright (�) - 2007 - CAPARROS S�bastien (Camaris)

Codeur officiel: Camaris & Max485
http://forum.epic-arena.fr

*/

$lang["desc"] = "Description";
$lang["pdbati"] = "Productions du batiment";
$lang["niv"] = "Niveau";
$lang["capacites"] = "Capacit�s de stockage du batiment";


?>