<?php

//=module technologie.php

// Si la constante n'est pas defini on bloque l'execution du fichier
if(!defined('PHPSIMUL_PAGES') || @PHPSIMUL_PAGES != 'PHPSIMULLL') 
{
	die('Erreur 404 - Le fichier n\'a pas �t� trouv�');
}

/* 

PHPsimul : Cr�ez votre jeu de simulation en PHP
Copyright (�) - 2007 - CAPARROS S�bastien (Camaris)

Codeur officiel: Camaris & Max485
http://forum.epic-arena.fr

*/

$lang["listec"] = "Liste des Constructions :";
$lang["batiments"] = "Batiments";
$lang["necessite"] = "N�c�ssite :";
$lang["rbat"] = "Requiert un batiment";
$lang["niveau"] = "niveau";
$lang["rtech"] = "Requiert une technologie";
$lang["technos"] = "Recherches";
$lang["chantier"] = "Chantier";
$lang["def"] = "D�fenses";


?>