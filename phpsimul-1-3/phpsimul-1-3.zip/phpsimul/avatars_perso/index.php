<?php

die('Erreur 404 - Le fichier n\'a pas �t� trouv�');

?>